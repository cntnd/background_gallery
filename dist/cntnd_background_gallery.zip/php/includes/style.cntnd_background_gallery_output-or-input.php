<style>
<?= file_get_contents($cfgClient[$client]["module"]["path"].'cntnd_background_gallery/css/cntnd_background_gallery.css') ?>
</style>
